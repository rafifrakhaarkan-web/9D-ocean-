import { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  ClipboardCheck, 
  BookOpen, 
  Wallet,
  Waves,
  User,
  Calendar,
  TrendingUp,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Stethoscope,
  FileEdit,
  ChevronLeft,
  Trash2,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { students, motivationalQuotes } from '@/data/students';
import type { Page, AttendanceStatus, AttendanceRecord, JournalEntry, DailyCash, MonthlyCash } from '@/types';
import './App.css';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [currentDate, setCurrentDate] = useState<string>('');
  const [quote, setQuote] = useState('');
  
  // Attendance state
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  
  // Journal state
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([]);
  const [journalForm, setJournalForm] = useState({ subject: '', topic: '', notes: '' });
  
  // Cash state
  const [monthlyCash, setMonthlyCash] = useState<MonthlyCash[]>(
    students.map(s => ({ studentId: s.id, amount: 0 }))
  );
  const [dailyCash, setDailyCash] = useState<DailyCash[]>(
    students.map(s => ({ studentId: s.id, days: [false, false, false, false, false] }))
  );

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    setCurrentDate(today);
    setQuote(motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]);
    
    // Load saved data from localStorage
    const savedAttendance = localStorage.getItem('attendance');
    const savedJournal = localStorage.getItem('journal');
    const savedMonthlyCash = localStorage.getItem('monthlyCash');
    const savedDailyCash = localStorage.getItem('dailyCash');
    
    if (savedAttendance) setAttendance(JSON.parse(savedAttendance));
    if (savedJournal) setJournalEntries(JSON.parse(savedJournal));
    if (savedMonthlyCash) setMonthlyCash(JSON.parse(savedMonthlyCash));
    if (savedDailyCash) setDailyCash(JSON.parse(savedDailyCash));
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('journal', JSON.stringify(journalEntries));
  }, [journalEntries]);

  useEffect(() => {
    localStorage.setItem('monthlyCash', JSON.stringify(monthlyCash));
  }, [monthlyCash]);

  useEffect(() => {
    localStorage.setItem('dailyCash', JSON.stringify(dailyCash));
  }, [dailyCash]);

  // Attendance functions
  const handleAttendanceChange = (studentId: number, status: AttendanceStatus) => {
    setAttendance(prev => {
      const existing = prev.find(a => a.studentId === studentId && a.date === currentDate);
      if (existing) {
        return prev.map(a => 
          a.studentId === studentId && a.date === currentDate 
            ? { ...a, status } 
            : a
        );
      }
      return [...prev, { studentId, status, date: currentDate }];
    });
  };

  const getAttendanceStatus = (studentId: number): AttendanceStatus => {
    const record = attendance.find(a => a.studentId === studentId && a.date === currentDate);
    return record?.status || null;
  };

  // Stats
  const stats = useMemo(() => {
    const todayAttendance = attendance.filter(a => a.date === currentDate);
    const hadir = todayAttendance.filter(a => a.status === 'hadir').length;
    const sakit = todayAttendance.filter(a => a.status === 'sakit').length;
    const izin = todayAttendance.filter(a => a.status === 'izin').length;
    const alpa = todayAttendance.filter(a => a.status === 'alpa').length;
    const totalCash = monthlyCash.reduce((sum, c) => sum + c.amount, 0);
    
    return { hadir, sakit, izin, alpa, totalCash };
  }, [attendance, currentDate, monthlyCash]);

  // Journal functions
  const addJournalEntry = () => {
    if (journalForm.subject && journalForm.topic) {
      const newEntry: JournalEntry = {
        id: Date.now().toString(),
        date: currentDate,
        subject: journalForm.subject,
        topic: journalForm.topic,
        notes: journalForm.notes
      };
      setJournalEntries(prev => [newEntry, ...prev]);
      setJournalForm({ subject: '', topic: '', notes: '' });
    }
  };

  const deleteJournalEntry = (id: string) => {
    setJournalEntries(prev => prev.filter(e => e.id !== id));
  };

  // Cash functions
  const handleMonthlyCashChange = (studentId: number, amount: number) => {
    setMonthlyCash(prev => 
      prev.map(c => c.studentId === studentId ? { ...c, amount } : c)
    );
    
    // Auto-calculate daily cash (5000 = 5 days)
    const daysToCheck = Math.floor(amount / 1000);
    setDailyCash(prev =>
      prev.map(c => {
        if (c.studentId === studentId) {
          const newDays = [false, false, false, false, false];
          for (let i = 0; i < Math.min(daysToCheck, 5); i++) {
            newDays[i] = true;
          }
          return { ...c, days: newDays };
        }
        return c;
      })
    );
  };

  const handleDailyCashChange = (studentId: number, dayIndex: number) => {
    setDailyCash(prev =>
      prev.map(c => {
        if (c.studentId === studentId) {
          const newDays = [...c.days];
          newDays[dayIndex] = !newDays[dayIndex];
          return { ...c, days: newDays };
        }
        return c;
      })
    );
  };

  const getMonthlyCash = (studentId: number) => {
    return monthlyCash.find(c => c.studentId === studentId)?.amount || 0;
  };

  const getDailyCash = (studentId: number) => {
    return dailyCash.find(c => c.studentId === studentId)?.days || [false, false, false, false, false];
  };

  // Navigation
  const NavigationButton = ({ page, icon: Icon, label }: { page: Page; icon: any; label: string }) => (
    <Button
      variant={currentPage === page ? 'default' : 'ghost'}
      className={`w-full justify-start gap-3 ${currentPage === page ? 'bg-ocean-dark text-white' : 'text-ocean-dark hover:bg-ocean-light/30'}`}
      onClick={() => setCurrentPage(page)}
    >
      <Icon className="w-5 h-5" />
      {label}
    </Button>
  );

  // Dashboard Page
  const DashboardPage = () => (
    <div className="space-y-6 animate-fade-in">
      {/* Quote Card */}
      <Card className="bg-gradient-to-r from-ocean-light/40 to-ocean/30 border-ocean/30">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <Waves className="w-8 h-8 text-ocean-dark flex-shrink-0 mt-1" />
            <div>
              <p className="text-lg font-medium text-ocean-dark italic">"{quote}"</p>
              <p className="text-sm text-ocean-dark/70 mt-2">— Kata-kata penyemangat hari ini</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-700">{stats.hadir}</p>
                <p className="text-xs text-green-600">Hadir</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Stethoscope className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-yellow-700">{stats.sakit}</p>
                <p className="text-xs text-yellow-600">Sakit</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <AlertCircle className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-700">{stats.izin}</p>
                <p className="text-xs text-blue-600">Izin</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-red-700">{stats.alpa}</p>
                <p className="text-xs text-red-600">Alpa</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Total Cash Card */}
      <Card className="bg-gradient-to-r from-ocean to-ocean-dark text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-lg">
                <Wallet className="w-8 h-8" />
              </div>
              <div>
                <p className="text-ocean-light text-sm">Total Kas Kelas</p>
                <p className="text-3xl font-bold">Rp {stats.totalCash.toLocaleString()}</p>
              </div>
            </div>
            <TrendingUp className="w-12 h-12 text-ocean-light/50" />
          </div>
        </CardContent>
      </Card>

      {/* Quick Navigation */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button 
          variant="outline" 
          className="h-24 flex flex-col items-center justify-center gap-2 border-ocean/30 hover:bg-ocean-light/20"
          onClick={() => setCurrentPage('absen')}
        >
          <ClipboardCheck className="w-8 h-8 text-ocean" />
          <span className="text-ocean-dark font-medium">Absensi</span>
        </Button>
        <Button 
          variant="outline" 
          className="h-24 flex flex-col items-center justify-center gap-2 border-ocean/30 hover:bg-ocean-light/20"
          onClick={() => setCurrentPage('jurnal')}
        >
          <BookOpen className="w-8 h-8 text-ocean" />
          <span className="text-ocean-dark font-medium">Jurnal</span>
        </Button>
        <Button 
          variant="outline" 
          className="h-24 flex flex-col items-center justify-center gap-2 border-ocean/30 hover:bg-ocean-light/20"
          onClick={() => setCurrentPage('kas')}
        >
          <Wallet className="w-8 h-8 text-ocean" />
          <span className="text-ocean-dark font-medium">Kas</span>
        </Button>
      </div>
    </div>
  );

  // Attendance Page
  const AttendancePage = () => (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={() => setCurrentPage('dashboard')} className="gap-2">
          <ChevronLeft className="w-4 h-4" /> Kembali
        </Button>
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-ocean" />
          <Input 
            type="date" 
            value={currentDate}
            onChange={(e) => setCurrentDate(e.target.value)}
            className="w-auto border-ocean/30"
          />
        </div>
      </div>

      <Card className="border-ocean/30">
        <CardHeader className="bg-ocean-light/20">
          <CardTitle className="text-ocean-dark flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5" />
            Daftar Absensi Siswa
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-ocean-light/30">
                <tr>
                  <th className="px-4 py-3 text-left text-ocean-dark font-medium">No</th>
                  <th className="px-4 py-3 text-left text-ocean-dark font-medium">Nama Siswa</th>
                  <th className="px-4 py-3 text-center text-ocean-dark font-medium">Hadir</th>
                  <th className="px-4 py-3 text-center text-ocean-dark font-medium">Sakit</th>
                  <th className="px-4 py-3 text-center text-ocean-dark font-medium">Izin</th>
                  <th className="px-4 py-3 text-center text-ocean-dark font-medium">Alpa</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student, index) => {
                  const status = getAttendanceStatus(student.id);
                  return (
                    <tr key={student.id} className="border-t border-ocean/10 hover:bg-ocean-light/10">
                      <td className="px-4 py-3 text-ocean-dark/70">{index + 1}</td>
                      <td className="px-4 py-3 text-ocean-dark font-medium">{student.name}</td>
                      <td className="px-4 py-3 text-center">
                        <Checkbox 
                          checked={status === 'hadir'}
                          onCheckedChange={() => handleAttendanceChange(student.id, 'hadir')}
                          className="border-green-500 data-[state=checked]:bg-green-500"
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <Checkbox 
                          checked={status === 'sakit'}
                          onCheckedChange={() => handleAttendanceChange(student.id, 'sakit')}
                          className="border-yellow-500 data-[state=checked]:bg-yellow-500"
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <Checkbox 
                          checked={status === 'izin'}
                          onCheckedChange={() => handleAttendanceChange(student.id, 'izin')}
                          className="border-blue-500 data-[state=checked]:bg-blue-500"
                        />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <Checkbox 
                          checked={status === 'alpa'}
                          onCheckedChange={() => handleAttendanceChange(student.id, 'alpa')}
                          className="border-red-500 data-[state=checked]:bg-red-500"
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Journal Page
  const JournalPage = () => (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={() => setCurrentPage('dashboard')} className="gap-2">
          <ChevronLeft className="w-4 h-4" /> Kembali
        </Button>
      </div>

      <Card className="border-ocean/30">
        <CardHeader className="bg-ocean-light/20">
          <CardTitle className="text-ocean-dark flex items-center gap-2">
            <FileEdit className="w-5 h-5" />
            Tambah Jurnal Harian
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-ocean-dark">Mata Pelajaran</Label>
              <Input 
                placeholder="Contoh: Matematika"
                value={journalForm.subject}
                onChange={(e) => setJournalForm(prev => ({ ...prev, subject: e.target.value }))}
                className="border-ocean/30"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-ocean-dark">Materi/Pokok Bahasan</Label>
              <Input 
                placeholder="Contoh: Persamaan Linear"
                value={journalForm.topic}
                onChange={(e) => setJournalForm(prev => ({ ...prev, topic: e.target.value }))}
                className="border-ocean/30"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-ocean-dark">Catatan</Label>
            <Textarea 
              placeholder="Tambahkan catatan jika perlu..."
              value={journalForm.notes}
              onChange={(e) => setJournalForm(prev => ({ ...prev, notes: e.target.value }))}
              className="border-ocean/30"
              rows={3}
            />
          </div>
          <Button 
            onClick={addJournalEntry}
            className="bg-ocean hover:bg-ocean-dark"
            disabled={!journalForm.subject || !journalForm.topic}
          >
            <Plus className="w-4 h-4 mr-2" /> Tambah Jurnal
          </Button>
        </CardContent>
      </Card>

      <Card className="border-ocean/30">
        <CardHeader className="bg-ocean-light/20">
          <CardTitle className="text-ocean-dark flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Riwayat Jurnal
          </CardTitle>
        </CardHeader>
        <CardContent>
          {journalEntries.length === 0 ? (
            <p className="text-center text-ocean-dark/50 py-8">Belum ada jurnal yang ditambahkan</p>
          ) : (
            <div className="space-y-3">
              {journalEntries.map((entry) => (
                <div key={entry.id} className="p-4 bg-ocean-light/10 rounded-lg border border-ocean/20">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-ocean text-white">{entry.subject}</Badge>
                        <span className="text-sm text-ocean-dark/60">{entry.date}</span>
                      </div>
                      <p className="font-medium text-ocean-dark">{entry.topic}</p>
                      {entry.notes && (
                        <p className="text-sm text-ocean-dark/70 mt-1">{entry.notes}</p>
                      )}
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => deleteJournalEntry(entry.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // Cash Page
  const CashPage = () => (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={() => setCurrentPage('dashboard')} className="gap-2">
          <ChevronLeft className="w-4 h-4" /> Kembali
        </Button>
      </div>

      <Tabs defaultValue="bulanan" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-ocean-light/20">
          <TabsTrigger value="bulanan" className="data-[state=active]:bg-ocean data-[state=active]:text-white">
            Kas Bulanan
          </TabsTrigger>
          <TabsTrigger value="harian" className="data-[state=active]:bg-ocean data-[state=active]:text-white">
            Kas Harian
          </TabsTrigger>
        </TabsList>

        <TabsContent value="bulanan" className="mt-4">
          <Card className="border-ocean/30">
            <CardHeader className="bg-ocean-light/20">
              <CardTitle className="text-ocean-dark flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Kas Bulanan
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-ocean-light/30">
                    <tr>
                      <th className="px-4 py-3 text-left text-ocean-dark font-medium">No</th>
                      <th className="px-4 py-3 text-left text-ocean-dark font-medium">Nama Siswa</th>
                      <th className="px-4 py-3 text-right text-ocean-dark font-medium">Jumlah (Rp)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, index) => (
                      <tr key={student.id} className="border-t border-ocean/10 hover:bg-ocean-light/10">
                        <td className="px-4 py-3 text-ocean-dark/70">{index + 1}</td>
                        <td className="px-4 py-3 text-ocean-dark font-medium">{student.name}</td>
                        <td className="px-4 py-3 text-right">
                          <Input
                            type="number"
                            value={getMonthlyCash(student.id) || ''}
                            onChange={(e) => handleMonthlyCashChange(student.id, parseInt(e.target.value) || 0)}
                            className="w-32 ml-auto text-right border-ocean/30"
                            placeholder="0"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="harian" className="mt-4">
          <Card className="border-ocean/30">
            <CardHeader className="bg-ocean-light/20">
              <CardTitle className="text-ocean-dark flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Kas Harian (Senin - Jumat)
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-ocean-light/30">
                    <tr>
                      <th className="px-4 py-3 text-left text-ocean-dark font-medium">No</th>
                      <th className="px-4 py-3 text-left text-ocean-dark font-medium">Nama Siswa</th>
                      <th className="px-4 py-3 text-center text-ocean-dark font-medium">Sen</th>
                      <th className="px-4 py-3 text-center text-ocean-dark font-medium">Sel</th>
                      <th className="px-4 py-3 text-center text-ocean-dark font-medium">Rab</th>
                      <th className="px-4 py-3 text-center text-ocean-dark font-medium">Kam</th>
                      <th className="px-4 py-3 text-center text-ocean-dark font-medium">Jum</th>
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, index) => {
                      const days = getDailyCash(student.id);
                      return (
                        <tr key={student.id} className="border-t border-ocean/10 hover:bg-ocean-light/10">
                          <td className="px-4 py-3 text-ocean-dark/70">{index + 1}</td>
                          <td className="px-4 py-3 text-ocean-dark font-medium">{student.name}</td>
                          {days.map((checked, dayIndex) => (
                            <td key={dayIndex} className="px-4 py-3 text-center">
                              <Checkbox 
                                checked={checked}
                                onCheckedChange={() => handleDailyCashChange(student.id, dayIndex)}
                                className="border-ocean data-[state=checked]:bg-ocean"
                              />
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-ocean-light/20 via-white to-ocean/10">
      {/* Header */}
      <header className="bg-gradient-to-r from-ocean to-ocean-dark text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Waves className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Kelas 9D</h1>
                <p className="text-xs text-ocean-light">Sistem Pendataan Siswa</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-4">
              <Badge variant="secondary" className="bg-white/20 text-white">
                <User className="w-3 h-3 mr-1" /> 36 Siswa
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar Navigation */}
          <aside className="lg:w-64 flex-shrink-0">
            <Card className="border-ocean/30 sticky top-6">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  <NavigationButton page="dashboard" icon={LayoutDashboard} label="Dashboard" />
                  <NavigationButton page="absen" icon={ClipboardCheck} label="Absensi" />
                  <NavigationButton page="jurnal" icon={BookOpen} label="Jurnal" />
                  <NavigationButton page="kas" icon={Wallet} label="Kas" />
                </nav>
              </CardContent>
            </Card>
          </aside>

          {/* Page Content */}
          <main className="flex-1 min-w-0">
            {currentPage === 'dashboard' && <DashboardPage />}
            {currentPage === 'absen' && <AttendancePage />}
            {currentPage === 'jurnal' && <JournalPage />}
            {currentPage === 'kas' && <CashPage />}
          </main>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-ocean-dark text-white mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Waves className="w-5 h-5 text-ocean-light" />
              <span className="text-sm">Kelas 9D - Tema Laut</span>
            </div>
            <p className="text-sm text-ocean-light">© 2025 - Dibuat dengan ❤️ untuk kelas 9D</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
